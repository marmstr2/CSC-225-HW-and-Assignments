/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch2_location;

/**
 *
 * @author marmstr2
 */
public class Ch2_location {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Location somewhere = new Location(1,2);
        //THE TOSTRING 90 IS AN INSTANCE LEVEL METHOD
        //SO WE NEED AN INSTANCE CREATED FIRST TO CALL IT
        System.out.println("Location somewhere: " + somewhere.toString());
        Location somewhereElse = new Location(3,4);
        System.out.println("Location somewhereElse: " +somewhereElse.toString());
        
        //CLONE CREATS A COPY OF THE ORIGINAL
        //WITH THE SAME VALUES TO SEPERATE MEMORY ADDRESSES
        Location anotherWhere = somewhere.clone();
        System.out.println("Location anotherWhere: " +anotherWhere.toString());//instance level
        //CHANGE CLONE VALUE
        anotherWhere.setX(5);
        anotherWhere.setY(10);
        System.out.println("Location somewhere after change: " +somewhere.toString());//should stay same
        System.out.println("Location anotherWhere after change: " +anotherWhere.toString());//should change
        
        //THESE TWO REFERENCE THE SAME MEMORY
        //IF WE CHANGE ONE, IT CHANGES THE OTHER
        Location yetAnotherWhere = somewhere;
        System.out.println("Location yetAnotherWhere: " + yetAnotherWhere.toString());
        //CHANGE yetAnotherWhere
        yetAnotherWhere.setX(100);
        yetAnotherWhere.setY(200);
        System.out.println("Location somewhere after change: " +somewhere.toString());//changes bc reference
        System.out.println("Location yetAnotherWhere after change: " +yetAnotherWhere.toString());//changes
        
        //PRINT THE DISTANCE BETWEEN TWO LOCATIONS
        //THIS IS A STATIC METHOD CALLED AT THE CLASS LEVEL
        //WE DON'T NEED AN INSTANCE VARIABLE OF THE LOCATION CLASS TO USE IT
        double distance = Location.distance(somewhere, somewhereElse);
        System.out.println("Distance between somewhere and somewhereElse: " + distance);
        
        //FIND THE MIDPOINT BETWEEN TWO LOCATIONS
        //THIS WITH RETURN A LOCATION OBJECT (INSTANCE VARIABLE)
        Location midpoint = Location.midpoint(somewhere, somewhereElse);
        System.out.println("Midpoint betwe somewhere and somewhereElse: " + midpoint.toString());
        
        
        
        
    }
    
}
