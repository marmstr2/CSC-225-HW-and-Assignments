/*
 */
package interfaceexample;

/**
 *
 * @author marmstr2
 */
public interface IClock {
    
    void displayTime();//public implied in interface
    void setAlarm();
    void invokeAlarm();
    void disableAlarm();
    void tickSeconds();
    void tickMinutes();
    void tickHours();
    
}
