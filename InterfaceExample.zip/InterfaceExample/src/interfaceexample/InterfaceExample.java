/*
 * NOTE FOR MOUSE MAZE: USE INTEFACE FOR EACH MOUSE (GREY MOUSE, WHITE MOUSE, UPRIGHT MOUSE, ETC.)
 *              DRAW, MOVE?, EAT CHEESE, ETC. FOR EACH MOUSE.
 */
package interfaceexample;

import java.util.ArrayList;

/**
 *
 * @author marmstr2
 */
public class InterfaceExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Clock clock = new Clock();
//        clock.displayTime();
        
        DigitalClock dClock = new DigitalClock ();
//        dClock.displayTime();
        
        AnalogClock aClock = new AnalogClock ();
//        aClock.displayTime();
        
        ArrayList<IClock> listOfClocks = new ArrayList<>();
        listOfClocks.add(clock);
        listOfClocks.add(dClock);
        listOfClocks.add(aClock);
        for (IClock item: listOfClocks) {
            item.displayTime();
    }
    } 
}
