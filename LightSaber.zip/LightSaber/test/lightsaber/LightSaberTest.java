/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lightsaber;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author marmstr2
 */
public class LightSaberTest {
    
    public LightSaberTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class LightSaber.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        LightSaber.main(args);
    
    }

    /**
     * Test of GetColor method, of class LightSaber.
     */
    @Test
    public void testGetColor() {
        System.out.println("GetColor");
        LightSaber instance = new LightSaber();
        String expResult = "";
        String result = instance.GetColor();
        assertEquals(expResult, result);

    }

    /**
     * Test of SetColor method, of class LightSaber.
     */
    @Test
    public void testSetColor() {
        System.out.println("SetColor");
        String color = "";
        LightSaber instance = new LightSaber();
        instance.SetColor(color);

    }

    /**
     * Test of Swing method, of class LightSaber.
     */
    @Test
    public void testSwing() {
        System.out.println("Swing");
        String expResult = "";
        String result = LightSaber.Swing();
        //assertEquals(expResult, result);

    }

    /**
     * Test of Swing2 method, of class LightSaber.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testSwing2_NullInput_IllegalArgumenException() {
        System.out.println("Swing2");
        LightSaber instance = new LightSaber();
        String sound = null;
        String expResult = "";
        String result = instance.Swing2(sound);
        assertEquals(expResult, result);
    }
    
     @Test
    public void testSwing2_ValidInput_ColorAndSound() {
        System.out.println("Swing2");
        LightSaber instance = new LightSaber("Purple");
        String sound = "asdf";
        String expResult = "Purple" + " "+ sound;
        String result = instance.Swing2(sound);
        assertEquals(expResult, result);
    }
    
}
