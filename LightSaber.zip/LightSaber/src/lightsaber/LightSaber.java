/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lightsaber;

/**
 *
 * @author marmstr2
 */
public class LightSaber {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println(LightSaber.Swing()); //class level
        
        LightSaber wooWoom = new LightSaber(); //used constructor to creat instance object; instance level has to be used on a certain object
        wooWoom.SetColor("Red");
        System.out.println(wooWoom.Swing2("yay"));
        
        LightSaber wooWoom2 = new LightSaber();
        wooWoom2.SetColor("Blue");
        System.out.println(wooWoom2.Swing2("Woohoo"));
        
        LightSaber wooWoom3 = new LightSaber("Green");//used custom constructor to create object
        System.out.println(wooWoom3.Swing2("Boo!"));
    }
    //Constructors
    public LightSaber() { //java creates automatically (no parameters) 
        //right click, insert code, constructor     default constructor
    }
    
    public LightSaber(String color) { //custom color constructor
        this.color = color;
    }
    
    //------------------------------------------------------------------------
    //properties===instance variables
    //------------------------------------------------------------------------
 
    //COLOR
    private String color = "";
    public String GetColor() {return color;}//getter method: right click,insert code
    public void SetColor(String color) {this.color = color;}//this instase colo will be whatever we say
    
    //HANDLE
    private String handle= "";
    
    
    //-------------------------------------------------------------------------
    //METHODS     (nice visual)
    //-------------------------------------------------------------------------
    public static String Swing () {
        return "Crash"; //does not have color property with it, class level
    }
    public String Swing2 (String sound) {//instance level
        if (sound == null){
            throw new IllegalArgumentException();
        } else {
        return color +" "+ sound;
    }
    }
    
}
