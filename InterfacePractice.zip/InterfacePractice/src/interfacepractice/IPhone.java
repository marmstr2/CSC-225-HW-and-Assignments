/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfacepractice;

/**
 *
 * @author marmstr2
 */
public interface IPhone {
    void call();
    void recieveCall();
    void text();
    void playGame();
    void socialMedia();
    void email();
    void accessInternet();
    void music();
    void calendar();
    void calculator();
    void camera();
    
}
