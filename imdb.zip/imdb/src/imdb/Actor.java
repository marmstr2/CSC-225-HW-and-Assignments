/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imdb;

/**
 *
 * @author mque
 */
public class Actor {
    private String name;
    public String GetName () { return name; }
    public void SetName (String name) {this.name = name;}
   
    public Actor () {}
    public Actor (String name){this.name = name;} 
    
}

