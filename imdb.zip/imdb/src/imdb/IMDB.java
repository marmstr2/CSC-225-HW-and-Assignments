/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package imdb;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author mque
 */
public class IMDB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      Actor emmaWatson = new Actor ("Emma Watson");
      Actor maggieSmith = new Actor ("Maggie Smith");
      Actor danielRadcliff = new Actor ("Daniel Radcliff");
      Actor danStevens = new Actor ("Dan Stevens");
      Actor ewanMcgregor = new Actor ("Ewan Mcgregor");
      Actor jamesMcAvoy = new Actor ("James McAvoy");
      Actor andrewScott = new Actor ("Andrew Scott");
      Actor jenniferLawerance = new Actor ("Jennifer Lawerance");
      Actor liamHemsworth = new Actor ("Liam Hemsworth");
      Actor elizabethBanks = new Actor("Elizabeth Banks");
     
      Movie harryPotter = new Movie ("Harry Potter and the Sorcerer's Stone");
      Movie beautyBeast = new Movie ("Beauty and the Beast");
      Movie hungerGames = new Movie ("Hunger Games");
      Movie frankenstein = new Movie ("Victor Frankenstein");
      
      Actor[] actorArray = new Actor [] {
          emmaWatson, maggieSmith, danielRadcliff, danStevens, ewanMcgregor, 
          jamesMcAvoy, andrewScott, jenniferLawerance, liamHemsworth, 
          elizabethBanks};
     
      HashMap<String, Actor[]> actorMap = new HashMap<>();
    
      actorMap.put(harryPotter.getTitle(), new Actor [] {emmaWatson, maggieSmith, danielRadcliff});
      actorMap.put(beautyBeast.getTitle(), new Actor [] {emmaWatson, danStevens, ewanMcgregor});
      actorMap.put(frankenstein.getTitle(), new Actor [] {danielRadcliff, jamesMcAvoy, andrewScott});
      actorMap.put(hungerGames.getTitle(), new Actor [] {jenniferLawerance, liamHemsworth, elizabethBanks});
     
     Movie[] movieArray = new Movie[] {harryPotter, beautyBeast, frankenstein, hungerGames};
     
     HashMap<String, Movie[]> movieMap = new HashMap<>();
     
     movieMap.put(jamesMcAvoy.GetName(), new Movie [] {frankenstein});
     movieMap.put(emmaWatson.GetName(), new Movie [] {harryPotter, beautyBeast});
     movieMap.put(maggieSmith.GetName(), new Movie[] {harryPotter});
     movieMap.put(danielRadcliff.GetName(), new Movie[] {harryPotter, frankenstein});
     movieMap.put(danStevens.GetName(), new Movie[] {beautyBeast});
     movieMap.put(ewanMcgregor.GetName(), new Movie [] {frankenstein});
     movieMap.put(andrewScott.GetName(), new Movie [] {frankenstein});
     movieMap.put(jenniferLawerance.GetName(), new Movie [] {hungerGames});
     movieMap.put(liamHemsworth.GetName(), new Movie [] {hungerGames});
     movieMap.put(elizabethBanks.GetName(), new Movie [] {hungerGames});
     
    /* for(Map.Entry<String, Movie> item: movieMap.entrySet()){
         System.out.println (item.getValue().getTitle());
     }
     Scanner in = new Scanner(System.in);
     String inputTitle = in.nextLine();
     System.out.println(movieMap.get(inputTitle).getTitle());
        */ 
     Scanner in = new Scanner(System.in);
     
     
     String firstDisplay = "1";
     String secondDisplay = "2";
     String thirdDisplay = "3";
     String fourthDisplay ="4";
     String quit = "q";
     System.out.println("Display options: ");
         System.out.println("             1.) Enter an actor's full name to display all movies he/she has been in.");
         System.out.println("             2.) Enter a movie title to display the cast of the movie.");
         System.out.println("             3.) Displays all the actors and the movies they have been in.");
         System.out.println("             4.) Displays all the movies and the actors in them.");
         System.out.println("             q.) Quit.");
     System.out.println("Intput a number 1-4 or 'q' to quit.");
     String input = in.nextLine();
     while (!input.equals(quit)){
         if (input.equals(firstDisplay)) {
             System.out.println("Input an actor's full name.");
             String nameInput=in.nextLine();
             String output ="";
             //movieMap.get(nameInput);
             for(int i=0;i<movieMap.get(nameInput).length;i++) {
                 output=output+movieMap.get(nameInput)[i].getTitle()+"  ";
             }
             System.out.println(output);
             //System.out.println(nameInput);
             //System.out.println(Arrays.toString(movieMap.get(nameInput)));
             input=null;
             output="";
         }
         else if (input.equals(secondDisplay)) {
             System.out.println("Input a movie title.");
             String movieInput=in.nextLine();
             String output="";
             for(int i=0; i<actorMap.get(movieInput).length;i++){
                 output=output+actorMap.get(movieInput)[i].GetName()+"  ";
             }
             System.out.println(output);
             input=null;
             output="";
         }
         else if (input.equals(thirdDisplay)) {
             String output="";
             for (Map.Entry<String, Movie[]> item : movieMap.entrySet()) {
             output=(item.getKey())+" had the following movies: ";
             for(Movie x: item.getValue()){
                 output+=x.getTitle()+ "    ";
        }
             System.out.println(output);
             input=null;
             }}
         else if (input.equals(fourthDisplay)) {
             String output="";
             for (Map.Entry<String, Actor[]> item : actorMap.entrySet()) {
             output=(item.getKey())+" has the following cast: ";
             for(Actor x: item.getValue()){
                 output+=x.GetName()+ "    ";
        }
             System.out.println(output);
             input=null;
         }}
         else if (input.equals(quit)) {
             return;
         }
         else {System.out.println("Invalid option. Try again.");}
         System.out.println("");
         System.out.println("Display options: ");
         System.out.println("             1.) Enter an actor's full name to display all movies he/she has been in.");
         System.out.println("             2.) Enter a movie title to display the cast of the movie.");
         System.out.println("             3.) Displays all the actors and the movies they have been in.");
         System.out.println("             4.) Displays all the movies and the actors in them.");
         System.out.println("             q.) Quit.");
         System.out.println("Intput a number 1-4 or 'q' to quit.");
         input=in.nextLine();
     }

    // do{ System.out.println("Intput a number, q to quit.");
    // String input = in.nextLine();
    // if (input.equals(firstDisplay)) {
            // System.out.println("One");
             
         }
         //else if (input==secondDisplay) System.out.println("2");
        // else if (input==thirdDisplay) System.out.println("3");
        // else if(input==fourthDisplay) System.out.println("4");
    // }while(!input.equals(quit));

    
    
}

